"""
Jemy Chat - Single File Version
----------------------------------
Ye poora app SIRF is ek file mein hai (HTML/CSS/JS bhi andar hi hain),
taake GitHub par mobile se upload karna aasan ho — koi folder nahi chahiye.

Chalane ke steps:
  1) pip install -r requirements.txt
  2) .env file mein ANTHROPIC_API_KEY aur SECRET_KEY dalo
  3) python app.py
  4) http://localhost:5000 kholo
"""

import os
from datetime import datetime

from flask import Flask, request, jsonify, render_template_string, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import (
    LoginManager, UserMixin, login_user, logout_user, login_required, current_user
)
from werkzeug.security import generate_password_hash, check_password_hash
from dotenv import load_dotenv
import google.generativeai as genai

load_dotenv()

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "dev-secret-change-me")
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL", "sqlite:///jemychat.db")
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = "login"

# Google Gemini - free tier, no credit card required
genai.configure(api_key=os.environ.get("GEMINI_API_KEY"))
SYSTEM_PROMPT = "Tum Jemy Chat ho, ek friendly aur helpful AI assistant. User jis bhasha mein baat kare, usi mein jawab do."
gemini_model = genai.GenerativeModel("gemini-2.0-flash", system_instruction=SYSTEM_PROMPT)


# ---------------- DATABASE MODELS ----------------

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    conversations = db.relationship("Conversation", backref="user", lazy=True, cascade="all, delete-orphan")

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)


class Conversation(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    title = db.Column(db.String(200), default="New Chat")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    messages = db.relationship("Message", backref="conversation", lazy=True,
                                cascade="all, delete-orphan", order_by="Message.created_at")


class Message(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    conversation_id = db.Column(db.Integer, db.ForeignKey("conversation.id"), nullable=False)
    role = db.Column(db.String(20), nullable=False)
    content = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


# ---------------- HTML TEMPLATES (inline) ----------------

BASE_STYLE = """
<style>
:root { --indigo:#6C4CF1; --blue:#4A6BFF; --teal:#20D0C4; --bg:#FFFFFF; --bg-soft:#F5F5F7;
  --sidebar-bg:#1B1B2F; --sidebar-soft:#26263D; --text:#1B1B2F; --muted:#6B6B7B; }
* { box-sizing: border-box; }
body { margin:0; font-family:-apple-system,"Segoe UI",Arial,sans-serif; background:var(--bg); color:var(--text); }
.brand { display:flex; align-items:center; gap:8px; font-weight:700; font-size:17px; }
.brand-mark { display:inline-flex; align-items:center; justify-content:center; width:28px; height:28px;
  border-radius:8px; background:linear-gradient(135deg,var(--indigo),var(--teal)); color:white; font-size:14px; flex-shrink:0; }
.app { display:flex; height:100vh; }
.sidebar { width:260px; flex-shrink:0; background:var(--sidebar-bg); color:#E8E8F0; display:flex; flex-direction:column; padding:16px 12px; }
.sidebar-top { margin-bottom:14px; }
.sidebar-top .brand { color:white; margin-bottom:14px; padding:0 4px; }
.new-chat-btn { width:100%; border:none; background:var(--sidebar-soft); color:white; padding:10px 12px;
  border-radius:8px; cursor:pointer; font-size:13px; text-align:left; }
.new-chat-btn:hover { background:#303050; }
.convo-list { flex:1; overflow-y:auto; display:flex; flex-direction:column; gap:2px; margin-top:10px; }
.convo-item { display:flex; align-items:center; justify-content:space-between; padding:9px 10px; border-radius:8px;
  cursor:pointer; font-size:13px; color:#C9C9D6; }
.convo-item:hover, .convo-item.active { background:var(--sidebar-soft); }
.convo-item.active { color:white; }
.convo-title { overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.convo-delete { border:none; background:transparent; color:#8A8AA0; cursor:pointer; font-size:16px; padding:0 4px; display:none; }
.convo-item:hover .convo-delete { display:block; }
.convo-delete:hover { color:#FF6B6B; }
.sidebar-bottom { border-top:1px solid #33334D; padding-top:12px; margin-top:8px; display:flex;
  justify-content:space-between; align-items:center; font-size:13px; }
.user-name { color:#C9C9D6; }
.logout-link { color:#8A8AA0; text-decoration:none; }
.logout-link:hover { color:white; }
.main { flex:1; display:flex; flex-direction:column; min-width:0; }
.chat-window { flex:1; overflow-y:auto; padding:24px 16px 12px; max-width:760px; width:100%; margin:0 auto; }
.welcome { text-align:center; margin-top:15vh; color:var(--muted); }
.welcome h1 { color:var(--text); font-size:24px; margin-bottom:6px; }
.message-row { display:flex; margin-bottom:16px; }
.message-row.user { justify-content:flex-end; }
.message-row.assistant { justify-content:flex-start; }
.bubble { max-width:80%; padding:10px 14px; border-radius:14px; line-height:1.5; font-size:15px; white-space:pre-wrap; }
.message-row.user .bubble { background:linear-gradient(135deg,var(--indigo),var(--blue)); color:white; border-bottom-right-radius:4px; }
.message-row.assistant .bubble { background:#F0F0F5; color:var(--text); border-bottom-left-radius:4px; }
.input-bar { border-top:1px solid #EAEAEE; padding:14px 16px; }
#chatForm { max-width:760px; margin:0 auto; display:flex; gap:8px; align-items:flex-end; background:var(--bg-soft);
  border-radius:14px; padding:8px 8px 8px 14px; }
#userInput { flex:1; border:none; background:transparent; resize:none; font-size:15px; font-family:inherit;
  outline:none; max-height:140px; padding:6px 0; }
#sendBtn { border:none; background:linear-gradient(135deg,var(--indigo),var(--blue)); color:white; padding:10px 18px;
  border-radius:10px; cursor:pointer; font-weight:600; font-size:14px; }
#sendBtn:disabled { opacity:0.6; cursor:not-allowed; }
.auth-page { min-height:100vh; display:flex; align-items:center; justify-content:center; background:var(--bg-soft); padding:20px; }
.auth-card { width:100%; max-width:380px; background:white; border-radius:16px; padding:32px 28px; box-shadow:0 8px 30px rgba(0,0,0,0.08); }
.auth-brand { display:flex; align-items:center; gap:8px; font-weight:700; font-size:17px; margin-bottom:22px; }
.auth-card h1 { font-size:21px; margin:0 0 4px; }
.auth-sub { color:var(--muted); font-size:13.5px; margin:0 0 20px; }
.flash { background:#FEECEC; color:#C0392B; font-size:13px; padding:10px 12px; border-radius:8px; margin-bottom:16px; }
.auth-form { display:flex; flex-direction:column; gap:4px; }
.auth-form label { font-size:12.5px; color:var(--muted); margin-top:10px; }
.auth-form input { border:1px solid #E2E2E8; border-radius:8px; padding:10px 12px; font-size:14px; outline:none; font-family:inherit; }
.auth-form input:focus { border-color:var(--indigo); }
.auth-btn { margin-top:18px; border:none; background:linear-gradient(135deg,var(--indigo),var(--blue)); color:white;
  padding:11px; border-radius:8px; font-weight:600; font-size:14.5px; cursor:pointer; }
.auth-switch { text-align:center; font-size:13px; color:var(--muted); margin-top:18px; }
.auth-switch a { color:var(--indigo); text-decoration:none; font-weight:600; }
@media (max-width:700px) {
  .sidebar { position:fixed; z-index:10; height:100vh; transform:translateX(-100%); transition:transform 0.2s; }
  .sidebar.open { transform:translateX(0); }
}
</style>
"""

LOGIN_HTML = """
<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login — Jemy Chat</title>""" + BASE_STYLE + """</head><body>
<div class="auth-page"><div class="auth-card">
  <div class="auth-brand"><span class="brand-mark">✦</span><span>Jemy Chat</span></div>
  <h1>Wapas aane par khushi hui</h1>
  <p class="auth-sub">Apne account mein login karein</p>
  {% with messages = get_flashed_messages() %}{% if messages %}<div class="flash">{{ messages[0] }}</div>{% endif %}{% endwith %}
  <form method="POST" class="auth-form">
    <label>Email</label><input type="email" name="email" required autofocus>
    <label>Password</label><input type="password" name="password" required>
    <button type="submit" class="auth-btn">Login</button>
  </form>
  <p class="auth-switch">Account nahi hai? <a href="{{ url_for('register') }}">Sign up karein</a></p>
</div></div></body></html>
"""

REGISTER_HTML = """
<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Sign Up — Jemy Chat</title>""" + BASE_STYLE + """</head><body>
<div class="auth-page"><div class="auth-card">
  <div class="auth-brand"><span class="brand-mark">✦</span><span>Jemy Chat</span></div>
  <h1>Naya account banayein</h1>
  <p class="auth-sub">Kuch second mein shuru ho jayein</p>
  {% with messages = get_flashed_messages() %}{% if messages %}<div class="flash">{{ messages[0] }}</div>{% endif %}{% endwith %}
  <form method="POST" class="auth-form">
    <label>Username</label><input type="text" name="username" required autofocus>
    <label>Email</label><input type="email" name="email" required>
    <label>Password</label><input type="password" name="password" required minlength="6">
    <button type="submit" class="auth-btn">Sign Up</button>
  </form>
  <p class="auth-switch">Pehle se account hai? <a href="{{ url_for('login') }}">Login karein</a></p>
</div></div></body></html>
"""

INDEX_HTML = """
<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Jemy Chat</title>""" + BASE_STYLE + """</head><body>
<div class="app">
  <aside class="sidebar">
    <div class="sidebar-top">
      <div class="brand"><span class="brand-mark">✦</span><span>Jemy Chat</span></div>
      <button id="newChatBtn" class="new-chat-btn">+ New Chat</button>
    </div>
    <div id="convoList" class="convo-list">
      {% for c in conversations %}
      <div class="convo-item" data-id="{{ c.id }}">
        <span class="convo-title">{{ c.title }}</span>
        <button class="convo-delete" data-id="{{ c.id }}" title="Delete">×</button>
      </div>
      {% endfor %}
    </div>
    <div class="sidebar-bottom">
      <span class="user-name">{{ user.username }}</span>
      <a href="{{ url_for('logout') }}" class="logout-link">Logout</a>
    </div>
  </aside>
  <div class="main">
    <main id="chatWindow" class="chat-window">
      <div class="welcome"><h1>Jemy Chat mein aapka swagat hai</h1>
      <p>Naya chat shuru karein ya sidebar se purana chat kholein.</p></div>
    </main>
    <footer class="input-bar">
      <form id="chatForm">
        <textarea id="userInput" placeholder="Apna message likhein..." rows="1"></textarea>
        <button type="submit" id="sendBtn">Send</button>
      </form>
    </footer>
  </div>
</div>
<script>
const chatWindow=document.getElementById("chatWindow"),chatForm=document.getElementById("chatForm"),
userInput=document.getElementById("userInput"),sendBtn=document.getElementById("sendBtn"),
newChatBtn=document.getElementById("newChatBtn"),convoList=document.getElementById("convoList");
let activeConvoId=null;
function showWelcome(){chatWindow.innerHTML=`<div class="welcome"><h1>Jemy Chat mein aapka swagat hai</h1><p>Naya chat shuru karein ya sidebar se purana chat kholein.</p></div>`;}
function addMessage(text,role){const w=chatWindow.querySelector(".welcome");if(w)w.remove();
const row=document.createElement("div");row.className=`message-row ${role}`;
const bubble=document.createElement("div");bubble.className="bubble";bubble.textContent=text;
row.appendChild(bubble);chatWindow.appendChild(row);chatWindow.scrollTop=chatWindow.scrollHeight;return bubble;}
function setActiveConvo(id){activeConvoId=id;document.querySelectorAll(".convo-item").forEach(el=>{el.classList.toggle("active",el.dataset.id===String(id));});}
async function loadConversation(id){setActiveConvo(id);chatWindow.innerHTML="";
const res=await fetch(`/api/conversations/${id}/messages`);const data=await res.json();
if(!data.messages||data.messages.length===0){showWelcome();return;}
data.messages.forEach(m=>addMessage(m.content,m.role));}
async function createNewConversation(){const res=await fetch("/api/conversations",{method:"POST"});const convo=await res.json();
const item=document.createElement("div");item.className="convo-item";item.dataset.id=convo.id;
item.innerHTML=`<span class="convo-title">${convo.title}</span><button class="convo-delete" data-id="${convo.id}" title="Delete">×</button>`;
convoList.prepend(item);attachConvoEvents(item);setActiveConvo(convo.id);showWelcome();return convo.id;}
function attachConvoEvents(item){item.addEventListener("click",(e)=>{if(e.target.classList.contains("convo-delete"))return;loadConversation(item.dataset.id);});
const delBtn=item.querySelector(".convo-delete");delBtn.addEventListener("click",async(e)=>{e.stopPropagation();const id=delBtn.dataset.id;
await fetch(`/api/conversations/${id}`,{method:"DELETE"});item.remove();if(String(activeConvoId)===String(id)){activeConvoId=null;showWelcome();}});}
document.querySelectorAll(".convo-item").forEach(attachConvoEvents);
async function sendMessage(message){if(!activeConvoId){activeConvoId=await createNewConversation();}
addMessage(message,"user");const aiBubble=addMessage("Jemy soch raha hai...","assistant");sendBtn.disabled=true;
try{const res=await fetch("/api/chat",{method:"POST",headers:{"Content-Type":"application/json"},
body:JSON.stringify({message,conversation_id:activeConvoId})});const data=await res.json();
if(data.error){aiBubble.textContent="Error: "+data.error;}else{aiBubble.textContent=data.reply;
const activeItem=document.querySelector(`.convo-item[data-id="${activeConvoId}"] .convo-title`);
if(activeItem&&data.title)activeItem.textContent=data.title;}}
catch(err){aiBubble.textContent="Connection error. Server chal raha hai check karein.";}
finally{sendBtn.disabled=false;chatWindow.scrollTop=chatWindow.scrollHeight;}}
chatForm.addEventListener("submit",(e)=>{e.preventDefault();const text=userInput.value.trim();if(!text)return;
userInput.value="";userInput.style.height="auto";sendMessage(text);});
userInput.addEventListener("keydown",(e)=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();chatForm.requestSubmit();}});
userInput.addEventListener("input",()=>{userInput.style.height="auto";userInput.style.height=userInput.scrollHeight+"px";});
newChatBtn.addEventListener("click",createNewConversation);
</script>
</body></html>
"""


# ---------------- ROUTES ----------------

@app.route("/register", methods=["GET", "POST"])
def register():
    if current_user.is_authenticated:
        return redirect(url_for("home"))
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        if not username or not email or not password:
            flash("Sab fields bharna zaroori hai.")
            return redirect(url_for("register"))
        if User.query.filter_by(email=email).first():
            flash("Ye email pehle se registered hai.")
            return redirect(url_for("register"))
        if User.query.filter_by(username=username).first():
            flash("Ye username pehle se liya gaya hai.")
            return redirect(url_for("register"))
        user = User(username=username, email=email)
        user.set_password(password)
        db.session.add(user)
        db.session.commit()
        login_user(user)
        return redirect(url_for("home"))
    return render_template_string(REGISTER_HTML)


@app.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("home"))
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        user = User.query.filter_by(email=email).first()
        if user and user.check_password(password):
            login_user(user)
            return redirect(url_for("home"))
        flash("Email ya password ghalat hai.")
        return redirect(url_for("login"))
    return render_template_string(LOGIN_HTML)


@app.route("/logout")
@login_required
def logout():
    logout_user()
    return redirect(url_for("login"))


@app.route("/")
@login_required
def home():
    conversations = Conversation.query.filter_by(user_id=current_user.id).order_by(Conversation.created_at.desc()).all()
    return render_template_string(INDEX_HTML, conversations=conversations, user=current_user)


@app.route("/api/conversations", methods=["POST"])
@login_required
def create_conversation():
    convo = Conversation(user_id=current_user.id, title="New Chat")
    db.session.add(convo)
    db.session.commit()
    return jsonify({"id": convo.id, "title": convo.title})


@app.route("/api/conversations/<int:convo_id>/messages", methods=["GET"])
@login_required
def get_messages(convo_id):
    convo = Conversation.query.filter_by(id=convo_id, user_id=current_user.id).first_or_404()
    messages = [{"role": m.role, "content": m.content} for m in convo.messages]
    return jsonify({"messages": messages, "title": convo.title})


@app.route("/api/conversations/<int:convo_id>", methods=["DELETE"])
@login_required
def delete_conversation(convo_id):
    convo = Conversation.query.filter_by(id=convo_id, user_id=current_user.id).first_or_404()
    db.session.delete(convo)
    db.session.commit()
    return jsonify({"status": "deleted"})


@app.route("/api/chat", methods=["POST"])
@login_required
def chat():
    data = request.get_json()
    convo_id = data.get("conversation_id")
    user_message = data.get("message", "").strip()
    if not user_message:
        return jsonify({"error": "Message khali hai"}), 400

    convo = Conversation.query.filter_by(id=convo_id, user_id=current_user.id).first_or_404()

    user_msg = Message(conversation_id=convo.id, role="user", content=user_message)
    db.session.add(user_msg)
    db.session.commit()

    if len(convo.messages) == 1:
        convo.title = user_message[:50]
        db.session.commit()

    # Gemini uses "model" instead of "assistant" as the role name
    history = [
        {"role": "model" if m.role == "assistant" else "user", "parts": [m.content]}
        for m in convo.messages
    ]

    try:
        # Last message is sent separately; everything before it is prior context
        chat_session = gemini_model.start_chat(history=history[:-1])
        response = chat_session.send_message(history[-1]["parts"][0])
        ai_reply = response.text

        ai_msg = Message(conversation_id=convo.id, role="assistant", content=ai_reply)
        db.session.add(ai_msg)
        db.session.commit()
        return jsonify({"reply": ai_reply, "title": convo.title})
    except Exception as e:
        return jsonify({"error": f"Kuch ghalat ho gaya: {str(e)}"}), 500


with app.app_context():
    db.create_all()

if __name__ == "__main__":
    app.run(debug=True, port=5000)
